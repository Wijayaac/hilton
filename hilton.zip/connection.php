<?php

function open_connection()
{
    $host = "localhost";
    $username = "root";
    $password = "";

    $databasename = "mi3b11el_hotel";

    $connect = mysqli_connect($host, $username, $password, $databasename);
    return $connect;
}
<div class="overlay">
    <div class="card bg-dark text-white over-img ">
        <div class="card-img-overlay">
            <h1 class="card-title header-over">Pemesanan Kamar Berhasil !</h1>
            <p class="card-text para-over">Silahkan Cek email anda untuk detail transaksi dan pembayaran</p>
        </div>
        <a href="index.php?pg=home"><button class="btn btn-warning btn-over text-light" type="button">Kembali <i
                    class="fas fa-arrow-right">
                </i></button></a>
    </div>
</div>